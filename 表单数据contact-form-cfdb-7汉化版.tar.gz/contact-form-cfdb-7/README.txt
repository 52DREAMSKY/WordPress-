wordpress后台保存contact form 7表单数据插件Contact Form DB

wordpress联系表单插件contact form 7是款非常好用的自定义表单插件，但美中不足的是访客提交的表单只能以邮件的形式发送到博主设定的接收邮箱中，而不会保存在wordpress数据库以及在后台显示。

Contact Form DB插件就弥补了这一点，通过Contact Form DB插件可以实现contact form 7表单数据保存到数据库，然后在wordpress后台显示出所有已提交的表单数据，并且还支持使用简码在网站前台调用，此外还支持导出多种格式的文件。

1、然后在网站后台——插件——安装插件——上传插件进行安装。

2、在后台——插件——已安装插件中启用“Contact Form DB”插件（如果你使用是中文版的wordpress，该插件显示的名称是“联系表格”）。

3、启用插件后，在网站后台左侧栏会出现一个“联系表格”的选项卡，点击该选项卡下的“联系人数据”进入表单数据列表界面，在这里便可以查看已经提交的contact form 7表单数据。








