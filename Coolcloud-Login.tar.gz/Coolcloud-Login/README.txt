Coolcloud Login 主题登录插件

1、在后台——插件——已安装插件中启用“coolcloud_login”插件