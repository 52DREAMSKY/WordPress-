WordPress 5.0 换回老版”Classic Editor”经典编辑器

WordPress 5.0 正式采用了全新的“Block Editor”编辑器，从而替换了原有“Classic Editor”编辑器，相信有很多人和我一样会不习惯或者不喜欢新编辑器，那么新版 WordPress 该如何换回原来的 WordPress 编辑器呢？

不可否认 WordPress 还是非常人性化的，至少会考虑和兼顾更多的用户，不然我也不可能青睐 WordPress，所以及时 WordPress 5.0 更换了全新的编辑器，但是也依旧给大家提供了快速便捷切换到原编辑器的插件：“Classic Editor”。

1. 通过 WordPress 后台菜单“插件”-“安装插件”；

2. 上传插件包，稍等片刻即可安装成功，点击“启用”；

3. 通过 WordPress 后台菜单“Settings”-“撰写”，进入设置，配置如下：

安装并启用“Classic Editor”插件后就会在“设置”-“撰写”中增加两个设置选项：

Default editor for all users 为所有用户默认编辑器

Allow users to switch editors 为允许用户切换编辑器

根据自己需要设置即可，如果你的只是个人博客，第一个选项设置为“Classic Editor”，第二个设置为“No”即可。